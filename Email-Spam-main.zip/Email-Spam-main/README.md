# Spam-Ham
A simple streamlit app to detect whether a message is Spam or Ham.


To run the app, run `streamlit run main.py` in terminal.


### Classification Algotithms:
- Naive Byes
